package com.example.adapter;

import android.content.Context;
import android.text.Layout;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.BTTH.MainActivity;
import com.example.model.Task;

import java.util.List;

public class adapter extends BaseAdapter {
    private MainActivity mainActivity;
    private int layout;
    private List<Task> taskList;
    private Context context;
    private Layout main;

    public adapter(MainActivity mainActivity, int layout, List<Task> taskList) {
        this.mainActivity = mainActivity;
        this.layout = layout;
        this.taskList = taskList;
    }

    public static class ViewHoder{
        TextView txt_name, txt;
        Button button;
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }


}
